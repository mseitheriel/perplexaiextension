# Contributing

Thanks for taking the time to contribute! This is a small, focused utility — contributions that keep it lean and reliable are most welcome.

---

## What's in scope

- Bug fixes (broken rendering, fetch errors, edge cases in the API response shape)
- UI improvements (layout, readability, accessibility)
- Support for new Perplexity API fields as they appear
- Browser compatibility improvements (e.g. Firefox MV3)
- Documentation fixes

## What's out of scope

- Features that require new permissions not already in the manifest
- Storing or syncing user data to external services
- Rewriting the extension in a framework (React, Vue, etc.) — vanilla JS is intentional

---

## Getting started

1. Fork the repo and clone your fork
2. Load the extension unpacked in Chrome (`chrome://extensions` → Developer mode → Load unpacked)
3. Make your changes to `popup.html` / `popup.js`
4. Reload the extension from the extensions page (↺ icon) and test in the popup
5. Open a pull request against `main`

No build step, no dependencies, no package manager required.

---

## Code style

- Plain HTML/CSS/JS — no transpilation, no bundler
- Keep `popup.js` self-contained; avoid splitting into multiple scripts
- CSS variables for all colours — don't hardcode hex values inline
- Prefer `const` and `let`; no `var`
- Use `n()` helper for safe number formatting with fallback
- Keep the `Raw JSON` tab working — it's the first debugging tool for API changes

---

## Reporting bugs

Open an issue with:

- What you expected to see
- What you actually see (screenshot or description)
- Which browser and version
- Whether the Raw JSON tab shows data or an error

---

## Submitting a pull request

- Keep PRs focused — one fix or feature per PR
- Update `CHANGELOG.md` under `[Unreleased]`
- If you add a new field from the API, add it to the relevant section in `renderDashboard()` and document it in the README's **How It Works** table
- PRs that break the Raw JSON tab will not be merged
