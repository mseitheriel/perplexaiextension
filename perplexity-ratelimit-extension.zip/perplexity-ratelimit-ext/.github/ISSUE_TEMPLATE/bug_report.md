---
name: Bug report
about: Something isn't working correctly
title: '[Bug] '
labels: bug
assignees: ''
---

## Describe the bug

A clear description of what's going wrong.

## Steps to reproduce

1. Open the extension popup
2. ...
3. See error / unexpected output

## Expected behaviour

What you expected to see.

## Actual behaviour

What you actually see. Screenshots are helpful.

## Raw JSON tab

Does the **Raw JSON** tab show data or an error? If it shows data, does it look complete?

## Environment

- Browser: [e.g. Chrome 122, Edge 120]
- OS: [e.g. Windows 11, macOS 14]
- Extension version: [shown in the popup footer]

## Additional context

Anything else that might be relevant.
