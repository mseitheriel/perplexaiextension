---
name: Feature request
about: Suggest an improvement or new capability
title: '[Feature] '
labels: enhancement
assignees: ''
---

## What problem does this solve?

A clear description of what you're trying to do that the extension doesn't currently support.

## Proposed solution

How you'd like it to work. Mockups or descriptions both work.

## Alternatives you've considered

Any other approaches you've thought about.

## Additional context

Anything else that might help.
